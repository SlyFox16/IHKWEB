yii-dropzone
============

A Yii extension for Dropzone.js